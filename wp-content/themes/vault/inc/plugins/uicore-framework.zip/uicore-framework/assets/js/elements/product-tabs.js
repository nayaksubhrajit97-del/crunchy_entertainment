/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./assets/src/frontend/js/elements/product-tabs.js":
/*!*********************************************************!*\
  !*** ./assets/src/frontend/js/elements/product-tabs.js ***!
  \*********************************************************/
/***/ (() => {

eval("function _typeof(o) { \"@babel/helpers - typeof\"; return _typeof = \"function\" == typeof Symbol && \"symbol\" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && \"function\" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? \"symbol\" : typeof o; }, _typeof(o); }\nfunction _classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError(\"Cannot call a class as a function\"); }\nfunction _defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, \"value\" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o); } }\nfunction _createClass(e, r, t) { return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, \"prototype\", { writable: !1 }), e; }\nfunction _toPropertyKey(t) { var i = _toPrimitive(t, \"string\"); return \"symbol\" == _typeof(i) ? i : i + \"\"; }\nfunction _toPrimitive(t, r) { if (\"object\" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || \"default\"); if (\"object\" != _typeof(i)) return i; throw new TypeError(\"@@toPrimitive must return a primitive value.\"); } return (\"string\" === r ? String : Number)(t); }\nfunction _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }\nfunction _possibleConstructorReturn(t, e) { if (e && (\"object\" == _typeof(e) || \"function\" == typeof e)) return e; if (void 0 !== e) throw new TypeError(\"Derived constructors may only return object or undefined\"); return _assertThisInitialized(t); }\nfunction _assertThisInitialized(e) { if (void 0 === e) throw new ReferenceError(\"this hasn't been initialised - super() hasn't been called\"); return e; }\nfunction _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }\nfunction _getPrototypeOf(t) { return _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function (t) { return t.__proto__ || Object.getPrototypeOf(t); }, _getPrototypeOf(t); }\nfunction _inherits(t, e) { if (\"function\" != typeof e && null !== e) throw new TypeError(\"Super expression must either be null or a function\"); t.prototype = Object.create(e && e.prototype, { constructor: { value: t, writable: !0, configurable: !0 } }), Object.defineProperty(t, \"prototype\", { writable: !1 }), e && _setPrototypeOf(t, e); }\nfunction _setPrototypeOf(t, e) { return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) { return t.__proto__ = e, t; }, _setPrototypeOf(t, e); }\n/**\n *  Woo Single Product Tabs script for Editor screen\n *  TODO: not working on editor. After fixing it, we can remove the 'render_type' => 'template' from the tab style control\n */\n\nwindow.addEventListener('DOMContentLoaded', function () {\n  var UicoreProductTabs = /*#__PURE__*/function (_elementorModules$fro) {\n    function UicoreProductTabs() {\n      _classCallCheck(this, UicoreProductTabs);\n      return _callSuper(this, UicoreProductTabs, arguments);\n    }\n    _inherits(UicoreProductTabs, _elementorModules$fro);\n    return _createClass(UicoreProductTabs, [{\n      key: \"triggerTabsInEditor\",\n      value: function triggerTabsInEditor() {\n        jQuery('.wc-tabs-wrapper, .woocommerce-tabs, #rating').trigger('init');\n      }\n    }, {\n      key: \"bindEvents\",\n      value: function bindEvents() {\n        if (elementorFrontend.isEditMode()) {\n          this.triggerTabsInEditor();\n        }\n      }\n    }, {\n      key: \"onElementChange\",\n      value: function onElementChange(propertyName) {\n        console.log('Triggered on editor');\n        var $properties = ['post_id', 'tabs'];\n        if ($properties.includes(propertyName)) {\n          this.triggerTabsInEditor();\n        }\n      }\n    }]);\n  }(elementorModules.frontend.handlers.Base);\n  jQuery(window).on('elementor/frontend/init', function () {\n    var addHandler = function addHandler($element) {\n      elementorFrontend.elementsHandler.addHandler(UicoreProductTabs, {\n        $element: $element\n      });\n    };\n    elementorFrontend.hooks.addAction('frontend/element_ready/uicore-woo-product-tabs.default', addHandler);\n  });\n});\n\n//# sourceURL=webpack://uicore-framework/./assets/src/frontend/js/elements/product-tabs.js?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./assets/src/frontend/js/elements/product-tabs.js"]();
/******/ 	
/******/ })()
;